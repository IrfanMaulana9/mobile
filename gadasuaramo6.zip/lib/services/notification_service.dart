import 'dart:async';
import 'dart:convert';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/notification_item.dart';
import '../firebase_options.dart';

// Top-level function for background message handler
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  print('[v0] Background message received: ${message.messageId}');
  print('[v0] Background message data: ${message.data}');
  print('[v0] Background message notification: ${message.notification?.title}');
}

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();
  
  final StreamController<NotificationItem> _notificationStreamController = 
      StreamController<NotificationItem>.broadcast();
  
  Stream<NotificationItem> get notificationStream => _notificationStreamController.stream;

  String? _fcmToken;
  String? get fcmToken => _fcmToken;

  Future<void> initialize() async {
    try {
      print('[v0] Starting FCM initialization...');
      
      // Request permission for iOS
      NotificationSettings settings = await _firebaseMessaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );

      print('[v0] Notification permission status: ${settings.authorizationStatus}');

      // Initialize local notifications
      await _initializeLocalNotifications();

      try {
        _fcmToken = await _firebaseMessaging.getToken().timeout(
          const Duration(seconds: 10),
          onTimeout: () {
            print('[v0] FCM token request timed out');
            return null;
          },
        );
        print('[v0] FCM Token: $_fcmToken');
      } catch (e) {
        print('[v0] Error getting FCM token: $e');
        print('[v0] Continuing without FCM token - check Firebase Console setup');
      }

      // Listen for token refresh
      _firebaseMessaging.onTokenRefresh.listen((newToken) {
        _fcmToken = newToken;
        print('[v0] FCM Token refreshed: $newToken');
      });

      // Set up background message handler
      FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

      // Handle foreground messages
      FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

      // Handle notification opened from background/terminated state
      FirebaseMessaging.onMessageOpenedApp.listen(_handleNotificationOpenedApp);

      // Check if app was opened from a notification (terminated state)
      RemoteMessage? initialMessage = await _firebaseMessaging.getInitialMessage();
      if (initialMessage != null) {
        print('[v0] App opened from terminated state via notification');
        _handleNotificationOpenedApp(initialMessage);
      }
      
      print('[v0] FCM initialization completed successfully');
    } catch (e) {
      print('[v0] Error initializing FCM: $e');
      print('[v0] App will continue without push notifications');
    }
  }

  Future<void> _initializeLocalNotifications() async {
    // Android initialization settings with custom sound
    const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');

    // iOS initialization settings
    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // Create notification channel for Android with custom sound
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'high_importance_channel',
      'High Importance Notifications',
      description: 'This channel is used for important notifications.',
      importance: Importance.high,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('tungsahur'), // Custom sound from raw folder
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    const AndroidNotificationChannel progressChannel = AndroidNotificationChannel(
      'progress_channel',
      'Progress Notifications',
      description: 'This channel is used for progress notifications.',
      importance: Importance.low,
      showBadge: false,
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(progressChannel);
  }

  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    print('[v0] Foreground message received: ${message.messageId}');
    print('[v0] Payload data: ${message.data}');
    print('[v0] Notification: ${message.notification?.title}');

    // Create notification item
    final notificationItem = NotificationItem(
      id: message.messageId ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: message.notification?.title ?? 'Notification',
      body: message.notification?.body ?? '',
      data: message.data,
      timestamp: DateTime.now(),
      isRead: false,
    );

    // Add to stream
    _notificationStreamController.add(notificationItem);

    // Show local notification with custom sound
    await _showLocalNotification(message);
  }

  Future<void> _showLocalNotification(RemoteMessage message) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'high_importance_channel',
      'High Importance Notifications',
      channelDescription: 'This channel is used for important notifications.',
      importance: Importance.high,
      priority: Priority.high,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('tungsahur'), // Custom sound
      enableVibration: true,
      fullScreenIntent: true,
      ticker: 'ticker',
    );

    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'tungsahur.mp3',
    );

    const NotificationDetails notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _localNotifications.show(
      message.notification.hashCode,
      message.notification?.title ?? 'Notification',
      message.notification?.body ?? '',
      notificationDetails,
      payload: jsonEncode(message.data),
    );
  }

  void _handleNotificationOpenedApp(RemoteMessage message) {
    print('[v0] Notification opened: ${message.messageId}');
    print('[v0] Notification data: ${message.data}');

    // Navigate to specific page based on data
    _navigateToPage(message.data);
  }

  void _onNotificationTapped(NotificationResponse response) {
    print('[v0] Local notification tapped');
    print('[v0] Payload: ${response.payload}');

    if (response.payload != null) {
      try {
        final data = jsonDecode(response.payload!);
        _navigateToPage(data);
      } catch (e) {
        print('[v0] Error parsing notification payload: $e');
      }
    }
  }

  void _navigateToPage(Map<String, dynamic> data) {
    // Navigate based on notification type
    final type = data['type'] ?? '';
    final route = data['route'] ?? '';

    print('[v0] Navigating to: type=$type, route=$route');

    if (route.isNotEmpty) {
      // Navigate to specific route
      Get.toNamed(route);
    } else {
      // Navigate based on type
      switch (type) {
        case 'promo':
          Get.toNamed('/promo');
          break;
        case 'booking':
        case 'order':
          Get.toNamed('/booking-history');
          break;
        case 'notification':
          Get.toNamed('/notifications');
          break;
        default:
          // Navigate to notifications page
          Get.toNamed('/notifications');
      }
    }
  }

  // Save notifications to local storage
  List<NotificationItem> getSavedNotifications() {
    // This would typically load from SharedPreferences or Hive
    // For now, return empty list
    return [];
  }

  Future<void> saveNotification(NotificationItem notification) async {
    final prefs = await SharedPreferences.getInstance();
    final notifications = getSavedNotifications();
    notifications.insert(0, notification);
    
    // Keep only last 50 notifications
    if (notifications.length > 50) {
      notifications.removeRange(50, notifications.length);
    }

    final jsonList = notifications.map((n) => n.toJson()).toList();
    await prefs.setString('notifications', jsonEncode(jsonList));
  }

  Future<void> updateNotification(NotificationItem notification) async {
    final prefs = await SharedPreferences.getInstance();
    final notifications = getSavedNotifications();
    final index = notifications.indexWhere((n) => n.id == notification.id);
    
    if (index != -1) {
      notifications[index] = notification;
      final jsonList = notifications.map((n) => n.toJson()).toList();
      await prefs.setString('notifications', jsonEncode(jsonList));
    }
  }

  Future<void> deleteNotification(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final notifications = getSavedNotifications();
    notifications.removeWhere((n) => n.id == id);
    
    final jsonList = notifications.map((n) => n.toJson()).toList();
    await prefs.setString('notifications', jsonEncode(jsonList));
  }

  Future<void> clearAllNotifications() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('notifications');
  }

  Future<void> showNotification({
    required String title,
    required String body,
    String? payload,
  }) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'high_importance_channel',
      'High Importance Notifications',
      channelDescription: 'This channel is used for important notifications.',
      importance: Importance.high,
      priority: Priority.high,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('tungsahur'), // Custom sound
      enableVibration: true,
      fullScreenIntent: true,
      ticker: 'ticker',
    );

    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'tungsahur.mp3',
    );

    const NotificationDetails notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    final id = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    
    await _localNotifications.show(
      id,
      title,
      body,
      notificationDetails,
      payload: payload,
    );

    // Create notification item and add to stream
    final notificationItem = NotificationItem(
      id: id.toString(),
      title: title,
      body: body,
      data: {'payload': payload ?? ''},
      timestamp: DateTime.now(),
      isRead: false,
    );

    _notificationStreamController.add(notificationItem);
  }

  Future<void> showProgressNotification({
    required String title,
    required int progress,
    required int maxProgress,
  }) async {
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'progress_channel',
      'Progress Notifications',
      channelDescription: 'This channel is used for progress notifications.',
      importance: Importance.low,
      showProgress: true,
      maxProgress: maxProgress,
      progress: progress,
      playSound: false,
      enableVibration: false,
      ongoing: progress < maxProgress,
    );

    const DarwinNotificationDetails iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: false,
      presentSound: false,
    );

    final NotificationDetails notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _localNotifications.show(
      999, // Fixed ID for progress notifications so they update the same notification
      title,
      progress < maxProgress 
          ? '$progress% complete' 
          : 'Download complete!',
      notificationDetails,
    );
  }

  void dispose() {
    _notificationStreamController.close();
  }
}
