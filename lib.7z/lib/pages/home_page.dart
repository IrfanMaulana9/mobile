import 'package:flutter/material.dart';
import 'weather_demo.dart';
import 'booking_page.dart';

class HomePage extends StatefulWidget {
  final bool isDark;
  final void Function(bool dark)? onChangeTheme;

  const HomePage({super.key, this.isDark = false, this.onChangeTheme});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late bool _isDark;

  @override
  void initState() {
    super.initState();
    _isDark = widget.isDark;
  }

  Route _fadeSlideRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, animation, secondary, child) {
        final fade = CurvedAnimation(parent: animation, curve: Curves.easeOut);
        final slide = Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero)
            .animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic));
        return FadeTransition(
          opacity: fade,
          child: SlideTransition(position: slide, child: child),
        );
      },
    );
  }

  Widget _navTile(
    BuildContext context, {
    required String title,
    required String subtitle,
    required Widget page,
    required String heroTag,
    IconData icon = Icons.cleaning_services,
  }) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      elevation: 0,
      color: cs.surface,
      child: ListTile(
        leading: Hero(
          tag: heroTag,
          child: CircleAvatar(
            backgroundColor: cs.primary,
            foregroundColor: cs.onPrimary,
            child: Icon(icon),
          ),
        ),
        title: Text(title, style: TextStyle(color: cs.onSurface, fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: TextStyle(color: cs.onSurface.withOpacity(0.7))),
        trailing: Icon(Icons.chevron_right, color: cs.onSurface),
        onTap: () => Navigator.of(context).push(_fadeSlideRoute(page)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Layanan Kebersihan'),
        backgroundColor: cs.primary,
        foregroundColor: cs.onPrimary,
        actions: [
          IconButton(
            tooltip: _isDark ? 'Ubah ke Mode Terang' : 'Ubah ke Mode Gelap',
            icon: Icon(_isDark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () {
              setState(() => _isDark = !_isDark);
              widget.onChangeTheme?.call(_isDark);
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'API & Services',
              style: TextStyle(
                color: cs.onSurface,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
          _navTile(
            context,
            title: 'Cuaca & Rekomendasi Cleaning',
            subtitle: 'API Open-Meteo: Cuaca real-time + saran layanan',
            page: const WeatherDemoPage(),
            heroTag: WeatherDemoPage.routeName,
            icon: Icons.cloud_queue,
          ),
          const SizedBox(height: 12),
          _navTile(
            context,
            title: 'Booking Layanan Kebersihan',
            subtitle: 'Map picker + OpenStreetMap + Open-Meteo weather',
            page: const BookingPage(),
            heroTag: BookingPage.routeName,
            icon: Icons.location_on,
          ),
          const SizedBox(height: 24),
          Text(
            'Fokus: Layanan booking kebersihan dengan cuaca real-time.',
            style: TextStyle(color: cs.onSurface.withOpacity(0.8)),
          ),
        ],
      ),
    );
  }
}
