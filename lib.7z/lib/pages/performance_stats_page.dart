import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/storage_controller.dart';
import 'dart:convert';

/// Page untuk detailed performance metrics
class PerformanceStatsPage extends StatelessWidget {
  static const String routeName = '/performance-stats';
  
  const PerformanceStatsPage({super.key});
  
  @override
  Widget build(BuildContext context) {
    final controller = Get.find<StorageController>();
    final report = controller.getPerformanceReport();
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Performance Report'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              Get.back();
              Get.back();
              Get.toNamed('/performance-stats');
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSummary(report),
            const SizedBox(height: 24),
            _buildDetailedMetrics(report),
            const SizedBox(height: 24),
            _buildRawJSON(report),
          ],
        ),
      ),
    );
  }
  
  Widget _buildSummary(Map<String, dynamic> report) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Summary',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Timestamp: ${report['timestamp']}'),
            Text('Pending Bookings: ${report['pendingBookingsCount']}'),
            const Divider(),
            _buildStorageRow('SharedPreferences', report['prefs']),
            _buildStorageRow('Hive', report['hive']),
            _buildStorageRow('Supabase', report['supabase']),
            _buildStorageRow('Sync', report['sync']),
          ],
        ),
      ),
    );
  }
  
  Widget _buildStorageRow(String title, Map<String, dynamic> data) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('Ops: ${data['total'] ?? 0}'),
              Text('Avg: ${data['avgTime'] ?? 0}ms'),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildDetailedMetrics(Map<String, dynamic> report) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Detailed Metrics',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        _buildMetricCard('SharedPreferences', report['prefs']),
        const SizedBox(height: 12),
        _buildMetricCard('Hive', report['hive']),
        const SizedBox(height: 12),
        _buildMetricCard('Supabase', report['supabase']),
        const SizedBox(height: 12),
        _buildMetricCard('Sync Manager', report['sync']),
      ],
    );
  }
  
  Widget _buildMetricCard(String title, Map<String, dynamic> data) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Total Operations: ${data['total'] ?? 0}'),
            Text('Average Execution Time: ${data['avgTime'] ?? 0}ms'),
            Text('Success Rate: ${data['successRate'] ?? "0%"}'),
          ],
        ),
      ),
    );
  }
  
  Widget _buildRawJSON(Map<String, dynamic> report) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Raw JSON Report',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(4),
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Text(
                  jsonEncode(report),
                  style: const TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 10,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
