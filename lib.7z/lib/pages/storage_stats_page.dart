import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/storage_controller.dart';
import '../widgets/storage_demo_card.dart';

/// Page untuk menampilkan storage statistics dan demo
class StorageStatsPage extends StatelessWidget {
  static const String routeName = '/storage-stats';
  
  const StorageStatsPage({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Storage Statistics'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const StorageDemoCard(),
            _buildBookingListSection(),
          ],
        ),
      ),
    );
  }
  
  Widget _buildBookingListSection() {
    final controller = Get.find<StorageController>();
    
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Booking History',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Obx(() {
            final bookings = controller.getAllBookings();
            if (bookings.isEmpty) {
              return const Center(
                child: Text('No bookings yet'),
              );
            }
            
            return ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: bookings.length,
              itemBuilder: (context, index) {
                final booking = bookings[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    title: Text(booking.customerName),
                    subtitle: Text(booking.serviceName),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'Rp ${booking.totalPrice.toStringAsFixed(0)}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text(
                          booking.synced ? 'Synced' : 'Pending',
                          style: TextStyle(
                            fontSize: 12,
                            color: booking.synced ? Colors.green : Colors.orange,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }),
        ],
      ),
    );
  }
}
