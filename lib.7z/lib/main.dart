import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'pages/home_page.dart';
import 'pages/weather_demo.dart';
import 'pages/booking_page.dart';

void main() {
  runApp(const CleaningServiceApp());
}

class CleaningServiceApp extends StatefulWidget {
  const CleaningServiceApp({super.key});

  @override
  State<CleaningServiceApp> createState() => _CleaningServiceAppState();
}

class _CleaningServiceAppState extends State<CleaningServiceApp> {
  ThemeMode _mode = ThemeMode.system;

  void _setMode(bool dark) {
    setState(() {
      _mode = dark ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Using Material 3 color system to generate complementary colors from the primary brand color
    final light = ColorScheme.fromSeed(
      seedColor: const Color(0xFF0052A5), // UMM Brand Blue
      brightness: Brightness.light,
      surface: const Color(0xFFFBFBFB), // Very light gray/white
    );
    final dark = ColorScheme.fromSeed(
      seedColor: const Color(0xFF0052A5),
      brightness: Brightness.dark,
      surface: const Color(0xFF121212), // Dark surface
    );

    return GetMaterialApp(
      title: 'Layanan Kebersihan UMM',
      theme: ThemeData(
        colorScheme: light,
        scaffoldBackgroundColor: const Color(0xFFFFFFFF), // Pure white
        useMaterial3: true,
        appBarTheme: AppBarTheme(
          backgroundColor: light.primary,
          foregroundColor: light.onPrimary,
          elevation: 0,
          centerTitle: true,
        ),
        cardTheme: CardThemeData(
          color: light.surface,
          elevation: 1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: light.primary,
            foregroundColor: light.onPrimary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: light.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: light.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: light.outline),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: light.outline),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: light.primary, width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
      darkTheme: ThemeData(
        colorScheme: dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        useMaterial3: true,
        appBarTheme: AppBarTheme(
          backgroundColor: dark.primary,
          foregroundColor: dark.onPrimary,
          elevation: 0,
          centerTitle: true,
        ),
        cardTheme: CardThemeData(
          color: dark.surface,
          elevation: 1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: dark.primary,
            foregroundColor: dark.onPrimary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: dark.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: dark.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: dark.outline),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: dark.outline),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: dark.primary, width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
      themeMode: _mode,
      routes: {
        '/': (_) => HomePage(
              isDark: _mode == ThemeMode.dark,
              onChangeTheme: _setMode,
            ),
        WeatherDemoPage.routeName: (_) => const WeatherDemoPage(),
        BookingPage.routeName: (_) => const BookingPage(),
      },
      initialRoute: '/',
    );
  }
}
