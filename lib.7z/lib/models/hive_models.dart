import 'package:hive/hive.dart';

part 'hive_models.g.dart';

/// Hive model untuk booking history
@HiveType(typeId: 0)
class HiveBooking extends HiveObject {
  @HiveField(0)
  late String id;
  
  @HiveField(1)
  late String customerName;
  
  @HiveField(2)
  late String phoneNumber;
  
  @HiveField(3)
  late String serviceName;
  
  @HiveField(4)
  late double latitude;
  
  @HiveField(5)
  late double longitude;
  
  @HiveField(6)
  late String address;
  
  @HiveField(7)
  late DateTime bookingDate;
  
  @HiveField(8)
  late String bookingTime;
  
  @HiveField(9)
  late double totalPrice;
  
  @HiveField(10)
  late String status; // 'pending', 'confirmed', 'completed', 'cancelled'
  
  @HiveField(11)
  late DateTime createdAt;
  
  @HiveField(12)
  late DateTime? updatedAt;
  
  @HiveField(13)
  late bool synced; // true jika sudah sync ke Supabase
  
  Map<String, dynamic> toJson() => {
    'id': id,
    'customerName': customerName,
    'phoneNumber': phoneNumber,
    'serviceName': serviceName,
    'latitude': latitude,
    'longitude': longitude,
    'address': address,
    'bookingDate': bookingDate.toIso8601String(),
    'bookingTime': bookingTime,
    'totalPrice': totalPrice,
    'status': status,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt?.toIso8601String(),
    'synced': synced,
  };
  
  static HiveBooking fromJson(Map<String, dynamic> json) {
    final booking = HiveBooking()
      ..id = json['id'] ?? ''
      ..customerName = json['customerName'] ?? ''
      ..phoneNumber = json['phoneNumber'] ?? ''
      ..serviceName = json['serviceName'] ?? ''
      ..latitude = json['latitude'] ?? 0.0
      ..longitude = json['longitude'] ?? 0.0
      ..address = json['address'] ?? ''
      ..bookingDate = json['bookingDate'] is String 
          ? DateTime.parse(json['bookingDate']) 
          : json['bookingDate'] ?? DateTime.now()
      ..bookingTime = json['bookingTime'] ?? ''
      ..totalPrice = (json['totalPrice'] ?? 0).toDouble()
      ..status = json['status'] ?? 'pending'
      ..createdAt = json['createdAt'] is String 
          ? DateTime.parse(json['createdAt']) 
          : json['createdAt'] ?? DateTime.now()
      ..updatedAt = json['updatedAt'] is String 
          ? DateTime.parse(json['updatedAt']) 
          : json['updatedAt']
      ..synced = json['synced'] ?? false;
    return booking;
  }
}

/// Hive model untuk cached weather data
@HiveType(typeId: 1)
class HiveCachedWeather extends HiveObject {
  @HiveField(0)
  late String locationKey;
  
  @HiveField(1)
  late double temperature;
  
  @HiveField(2)
  late double windSpeed;
  
  @HiveField(3)
  late int rainProbability;
  
  @HiveField(4)
  late DateTime cachedAt;
  
  bool isExpired() => DateTime.now().difference(cachedAt).inHours > 6;
  
  Map<String, dynamic> toJson() => {
    'locationKey': locationKey,
    'temperature': temperature,
    'windSpeed': windSpeed,
    'rainProbability': rainProbability,
    'cachedAt': cachedAt.toIso8601String(),
  };
}

/// Hive model untuk last used location
@HiveType(typeId: 2)
class HiveLastLocation extends HiveObject {
  @HiveField(0)
  late double latitude;
  
  @HiveField(1)
  late double longitude;
  
  @HiveField(2)
  late String address;
  
  @HiveField(3)
  late String? placeName;
  
  @HiveField(4)
  late DateTime usedAt;
  
  Map<String, dynamic> toJson() => {
    'latitude': latitude,
    'longitude': longitude,
    'address': address,
    'placeName': placeName,
    'usedAt': usedAt.toIso8601String(),
  };
}
