import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/booking.dart';
import '../services/weather_service.dart';
import '../services/location_service.dart';
import '../services/hive_service.dart';
import '../services/offline_sync_manager.dart';
import '../models/hive_models.dart';
import '../controllers/storage_controller.dart';

class BookingController extends GetxController {
  final bookingData = BookingData().obs;
  final weatherService = WeatherService();
  final locationService = LocationService();

  final isLoadingWeather = false.obs;
  final selectedLocation = Rxn<BookingLocation>();
  final currentWeather = Rxn();

  final availableServices = <CleaningService>[
    CleaningService(
      id: '1',
      name: 'Indoor Cleaning',
      description: 'Pembersihan ruangan dalam (ruang tamu, kamar, dapur)',
      price: 250000,
      type: 'indoor',
      estimatedHours: 2,
    ),
    CleaningService(
      id: '2',
      name: 'Outdoor Cleaning',
      description: 'Pembersihan area luar (halaman, teras, garasi)',
      price: 350000,
      type: 'outdoor',
      estimatedHours: 3,
    ),
    CleaningService(
      id: '3',
      name: 'Deep Cleaning',
      description: 'Pembersihan menyeluruh mencakup semua area',
      price: 500000,
      type: 'deep',
      estimatedHours: 4,
    ),
    CleaningService(
      id: '4',
      name: 'Window Cleaning',
      description: 'Pembersihan jendela, kaca, dan frame',
      price: 200000,
      type: 'window',
      estimatedHours: 1,
    ),
  ];

  late StorageController storageController;
  final offlineQueue = <HiveBooking>[].obs;

  @override
  Future<void> onInit() async {
    super.onInit();
    storageController = Get.find<StorageController>();

    // Load offline queue
    offlineQueue.value = storageController.getPendingBookings();
    print('[BookingController] Initialized with ${offlineQueue.length} pending bookings');
  }

  void setCustomerName(String name) {
    bookingData.update((data) => data!.customerName = name);
  }

  void setPhoneNumber(String phone) {
    bookingData.update((data) => data!.phoneNumber = phone);
  }

  void selectService(CleaningService service) {
    bookingData.update((data) => data!.selectedService = service);
  }

  void setBookingDate(DateTime date) {
    bookingData.update((data) => data!.bookingDate = date);
  }

  void setBookingTime(TimeOfDay time) {
    bookingData.update((data) => data!.bookingTime = time);
  }

  Future<void> loadWeatherForLocation(double lat, double lng) async {
    isLoadingWeather.value = true;
    try {
      final weather = await weatherService.getWeatherByCoordinates(
        latitude: lat,
        longitude: lng,
        location: 'Lokasi Pilihan',
      );
      currentWeather.value = weather;
      print('[v0] Weather loaded: ${weather.temperature}°C');
    } finally {
      isLoadingWeather.value = false;
    }
  }

  void setLocation(double lat, double lng, String address) {
    selectedLocation.value = BookingLocation(
      latitude: lat,
      longitude: lng,
      address: address,
    );
    bookingData.update((data) => data!.location = selectedLocation.value);
  }

  Future<double> getETA() async {
    if (selectedLocation.value == null) return 0;
    final distance = selectedLocation.value!.distanceFromUMM();
    // Assume 40 km/h average speed
    return distance / 40 * 60; // minutes
  }

  double calculateEstimatedPrice() {
    if (bookingData.value.selectedService == null) return 0;
    return bookingData.value.calculateTotalPrice();
  }

  double getDistanceFee() {
    if (bookingData.value.location == null) return 0;
    final distance = bookingData.value.location!.distanceFromUMM();
    return distance * 15000; // Rp per km
  }

  double getBasePrice() {
    return bookingData.value.selectedService?.price ?? 0;
  }

  bool hasWeatherWarnings() {
    if (currentWeather.value == null) return false;
    final weather = currentWeather.value;
    return !weather.isWindSafe() || weather.rainProbability > 50;
  }

  Future<bool> submitBooking() async {
    if (bookingData.value.customerName.isEmpty || 
        bookingData.value.phoneNumber.isEmpty ||
        bookingData.value.selectedService == null ||
        bookingData.value.location == null) {
      return false;
    }
    
    try {
      // Create Hive booking model
      final hiveBooking = HiveBooking()
        ..id = DateTime.now().millisecondsSinceEpoch.toString()
        ..customerName = bookingData.value.customerName
        ..phoneNumber = bookingData.value.phoneNumber
        ..serviceName = bookingData.value.selectedService!.name
        ..latitude = bookingData.value.location!.latitude
        ..longitude = bookingData.value.location!.longitude
        ..address = bookingData.value.location!.address
        ..bookingDate = bookingData.value.bookingDate ?? DateTime.now()
        ..bookingTime = bookingData.value.bookingTime?.format(Get.context!) ?? '09:00'
        ..totalPrice = bookingData.value.calculateTotalPrice()
        ..status = 'pending'
        ..createdAt = DateTime.now()
        ..synced = false;
      
      // Save using storage controller
      final success = await storageController.saveBookingLocally(hiveBooking);
      
      if (success) {
        // Save last address to prefs
        await storageController.prefsService.setLastAddress(
          bookingData.value.location!.address
        );
        
        // Reset booking data
        bookingData.value = BookingData();
        offlineQueue.refresh();
      }
      
      return success;
    } catch (e) {
      print('[BookingController] Error submitting booking: $e');
      return false;
    }
  }
  
  void loadLastAddress() {
    final lastAddress = storageController.prefsService.getLastAddress();
    if (lastAddress.isNotEmpty) {
      print('[BookingController] Loaded last address: $lastAddress');
    }
  }
}
