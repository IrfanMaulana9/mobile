import 'package:get/get.dart';
import '../services/prefs_service.dart';
import '../services/hive_service.dart';
import '../services/supabase_service.dart';
import '../services/offline_sync_manager.dart';
import '../models/hive_models.dart';
import '../models/storage_performance.dart';

/// Controller untuk manage semua storage operations dengan GetX
class StorageController extends GetxController {
  late PrefsService prefsService;
  late HiveService hiveService;
  late SupabaseService supabaseService;
  late OfflineSyncManager syncManager;
  
  final isOnline = true.obs;
  final syncInProgress = false.obs;
  final pendingBookingsCount = 0.obs;
  
  @override
  Future<void> onInit() async {
    super.onInit();
    
    // Initialize all services
    prefsService = PrefsService();
    await prefsService.init();
    
    hiveService = HiveService();
    await hiveService.init();
    
    supabaseService = SupabaseService();
    
    syncManager = OfflineSyncManager();
    await syncManager.init();
    
    // Check online status
    isOnline.value = await syncManager.isOnline();
    pendingBookingsCount.value = syncManager.getPendingCount();
    
    print('[StorageController] Initialized');
  }
  
  // ============ Preferences Management ============
  
  Future<void> setTheme(String theme) async {
    await prefsService.setTheme(theme);
  }
  
  String getTheme() => prefsService.getTheme();
  
  // ============ Booking Management ============
  
  Future<bool> saveBookingLocally(HiveBooking booking) async {
    try {
      final online = await syncManager.isOnline();
      
      // Always save to Hive first
      await hiveService.addBooking(booking);
      
      if (online && supabaseService.isAuthenticated) {
        // If online, sync immediately
        final result = await supabaseService.insertBooking(booking);
        if (result != null) {
          await hiveService.markBookingAsSynced(booking.id);
          return true;
        }
      } else {
        // Queue for offline sync
        await syncManager.queueOfflineBooking(booking);
      }
      
      pendingBookingsCount.value = syncManager.getPendingCount();
      return true;
    } catch (e) {
      print('[StorageController] Error saving booking: $e');
      return false;
    }
  }
  
  List<HiveBooking> getAllBookings() => hiveService.getAllBookings();
  
  HiveBooking? getBooking(String id) => hiveService.getBooking(id);
  
  List<HiveBooking> getPendingBookings() => hiveService.getPendingBookings();
  
  // ============ Sync Management ============
  
  Future<void> syncNow() async {
    syncInProgress.value = true;
    try {
      await syncManager.syncNow();
      pendingBookingsCount.value = syncManager.getPendingCount();
    } finally {
      syncInProgress.value = false;
    }
  }
  
  // ============ Performance Reporting ============
  
  Map<String, dynamic> getPerformanceReport() {
    final prefsReport = prefsService.getTracker().getPerformanceReport();
    final hiveReport = hiveService.getTracker().getPerformanceReport();
    final supabaseReport = supabaseService.getTracker().getPerformanceReport();
    final syncReport = syncManager.getTracker().getPerformanceReport();
    
    return {
      'timestamp': DateTime.now().toIso8601String(),
      'prefs': prefsReport,
      'hive': hiveReport,
      'supabase': supabaseReport,
      'sync': syncReport,
      'pendingBookingsCount': pendingBookingsCount.value,
    };
  }
  
  void clearAllLogs() {
    prefsService.getTracker().clearLogs();
    hiveService.getTracker().clearLogs();
    supabaseService.getTracker().clearLogs();
    syncManager.getTracker().clearLogs();
  }
}
