import 'package:connectivity_plus/connectivity_plus.dart';
import '../models/hive_models.dart';
import 'hive_service.dart';
import 'supabase_service.dart';
import '../models/storage_performance.dart';

/// Service untuk manage offline sync dan queue
class OfflineSyncManager {
  static final OfflineSyncManager _instance = OfflineSyncManager._internal();
  
  factory OfflineSyncManager() {
    return _instance;
  }
  
  OfflineSyncManager._internal();
  
  final HiveService _hiveService = HiveService();
  final SupabaseService _supabaseService = SupabaseService();
  final Connectivity _connectivity = Connectivity();
  final PerformanceTracker _tracker = PerformanceTracker();
  
  bool _isSyncing = false;
  
  /// Initialize offline sync manager dan setup connectivity listener
  Future<void> init() async {
    _connectivity.onConnectivityChanged.listen((result) {
      if (result.contains(ConnectivityResult.mobile) || 
          result.contains(ConnectivityResult.wifi)) {
        _syncPendingBookings();
      }
    });
    print('[OfflineSyncManager] Initialized');
  }
  
  /// Check apakah device terhubung internet
  Future<bool> isOnline() async {
    try {
      final result = await _connectivity.checkConnectivity();
      return result.contains(ConnectivityResult.mobile) || 
             result.contains(ConnectivityResult.wifi);
    } catch (e) {
      return false;
    }
  }
  
  /// Simpan booking ke queue offline
  Future<void> queueOfflineBooking(HiveBooking booking) async {
    booking.synced = false;
    await _hiveService.addBooking(booking);
    print('[OfflineSyncManager] Booking queued for offline: ${booking.id}');
  }
  
  /// Sync pending bookings ke Supabase ketika online
  Future<void> _syncPendingBookings() async {
    if (_isSyncing) return;
    _isSyncing = true;
    
    try {
      final isOnline = await this.isOnline();
      if (!isOnline) {
        _isSyncing = false;
        return;
      }
      
      final pendingBookings = _hiveService.getPendingBookings();
      print('[OfflineSyncManager] Starting sync of ${pendingBookings.length} pending bookings');
      
      for (final booking in pendingBookings) {
        final stopwatch = Stopwatch()..start();
        try {
          final result = await _supabaseService.insertBooking(booking);
          stopwatch.stop();
          
          if (result != null) {
            await _hiveService.markBookingAsSynced(booking.id);
            _tracker.addLog(StoragePerformanceLog(
              operation: 'write',
              storageType: 'supabase',
              dataKey: 'offline_sync_${booking.id}',
              executionTimeMs: stopwatch.elapsedMilliseconds,
              success: true,
              timestamp: DateTime.now(),
            ));
            print('[OfflineSyncManager] Synced booking: ${booking.id}');
          } else {
            _tracker.addLog(StoragePerformanceLog(
              operation: 'write',
              storageType: 'supabase',
              dataKey: 'offline_sync_${booking.id}',
              executionTimeMs: stopwatch.elapsedMilliseconds,
              success: false,
              errorMessage: 'Failed to insert booking',
              timestamp: DateTime.now(),
            ));
          }
        } catch (e) {
          stopwatch.stop();
          _tracker.addLog(StoragePerformanceLog(
            operation: 'write',
            storageType: 'supabase',
            dataKey: 'offline_sync_${booking.id}',
            executionTimeMs: stopwatch.elapsedMilliseconds,
            success: false,
            errorMessage: e.toString(),
            timestamp: DateTime.now(),
          ));
          print('[OfflineSyncManager] Error syncing booking ${booking.id}: $e');
        }
      }
      
      print('[OfflineSyncManager] Sync completed');
    } finally {
      _isSyncing = false;
    }
  }
  
  /// Manual trigger untuk sync
  Future<void> syncNow() async {
    await _syncPendingBookings();
  }
  
  int getPendingCount() => _hiveService.getPendingBookingsCount();
  
  PerformanceTracker getTracker() => _tracker;
}
