import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import '../models/storage_performance.dart';

/// Service untuk SharedPreferences - menyimpan data sederhana
class PrefsService {
  static final PrefsService _instance = PrefsService._internal();
  
  factory PrefsService() {
    return _instance;
  }
  
  PrefsService._internal();
  
  late SharedPreferences _prefs;
  final PerformanceTracker _tracker = PerformanceTracker();
  
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    print('[PrefsService] Initialized');
  }
  
  // ============ Theme Management ============
  
  Future<void> setTheme(String theme) async {
    final stopwatch = Stopwatch()..start();
    try {
      await _prefs.setString('app_theme', theme);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: 'app_theme',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: 'app_theme',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
    }
  }
  
  String getTheme() {
    final stopwatch = Stopwatch()..start();
    try {
      final theme = _prefs.getString('app_theme') ?? 'light';
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'prefs',
        dataKey: 'app_theme',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return theme;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'prefs',
        dataKey: 'app_theme',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return 'light';
    }
  }
  
  // ============ Last Address Management ============
  
  Future<void> setLastAddress(String address) async {
    final stopwatch = Stopwatch()..start();
    try {
      await _prefs.setString('last_address', address);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: 'last_address',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: 'last_address',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
    }
  }
  
  String getLastAddress() {
    final stopwatch = Stopwatch()..start();
    try {
      final address = _prefs.getString('last_address') ?? '';
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'prefs',
        dataKey: 'last_address',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return address;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'prefs',
        dataKey: 'last_address',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return '';
    }
  }
  
  // ============ Preferences Management ============
  
  Future<void> setBool(String key, bool value) async {
    final stopwatch = Stopwatch()..start();
    try {
      await _prefs.setBool(key, value);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: key,
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: key,
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
    }
  }
  
  bool getBool(String key, {bool defaultValue = false}) {
    final stopwatch = Stopwatch()..start();
    try {
      final value = _prefs.getBool(key) ?? defaultValue;
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'prefs',
        dataKey: key,
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return value;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'prefs',
        dataKey: key,
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return defaultValue;
    }
  }
  
  Future<void> setString(String key, String value) async {
    final stopwatch = Stopwatch()..start();
    try {
      await _prefs.setString(key, value);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: key,
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: key,
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
    }
  }
  
  String getString(String key, {String defaultValue = ''}) {
    final stopwatch = Stopwatch()..start();
    try {
      final value = _prefs.getString(key) ?? defaultValue;
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'prefs',
        dataKey: key,
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return value;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'prefs',
        dataKey: key,
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return defaultValue;
    }
  }
  
  Future<bool> clear() async {
    final stopwatch = Stopwatch()..start();
    try {
      final result = await _prefs.clear();
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: 'clear_all',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return result;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'prefs',
        dataKey: 'clear_all',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return false;
    }
  }
  
  PerformanceTracker getTracker() => _tracker;
}
