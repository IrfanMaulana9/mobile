import 'package:hive/hive.dart';
import '../models/hive_models.dart';
import '../models/storage_performance.dart';

/// Service untuk Hive - penyimpanan lokal terstruktur
class HiveService {
  static final HiveService _instance = HiveService._internal();
  
  factory HiveService() {
    return _instance;
  }
  
  HiveService._internal();
  
  late Box<HiveBooking> _bookingBox;
  late Box<HiveCachedWeather> _weatherBox;
  late Box<HiveLastLocation> _locationBox;
  final PerformanceTracker _tracker = PerformanceTracker();
  
  Future<void> init() async {
    // Register adapters
    Hive.registerAdapter(HiveBookingAdapter());
    Hive.registerAdapter(HiveCachedWeatherAdapter());
    Hive.registerAdapter(HiveLastLocationAdapter());
    
    // Open boxes
    _bookingBox = await Hive.openBox<HiveBooking>('bookings');
    _weatherBox = await Hive.openBox<HiveCachedWeather>('weather_cache');
    _locationBox = await Hive.openBox<HiveLastLocation>('locations');
    
    print('[HiveService] Initialized with ${_bookingBox.length} bookings');
  }
  
  // ============ Booking CRUD ============
  
  Future<void> addBooking(HiveBooking booking) async {
    final stopwatch = Stopwatch()..start();
    try {
      await _bookingBox.put(booking.id, booking);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'booking_${booking.id}',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'booking_${booking.id}',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      rethrow;
    }
  }
  
  HiveBooking? getBooking(String id) {
    final stopwatch = Stopwatch()..start();
    try {
      final booking = _bookingBox.get(id);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'booking_$id',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return booking;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'booking_$id',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return null;
    }
  }
  
  List<HiveBooking> getAllBookings() {
    final stopwatch = Stopwatch()..start();
    try {
      final bookings = _bookingBox.values.toList();
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'all_bookings',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return bookings;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'all_bookings',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return [];
    }
  }
  
  List<HiveBooking> getPendingBookings() {
    final stopwatch = Stopwatch()..start();
    try {
      final bookings = _bookingBox.values.where((b) => !b.synced).toList();
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'pending_bookings',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return bookings;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'pending_bookings',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return [];
    }
  }
  
  Future<void> updateBooking(HiveBooking booking) async {
    final stopwatch = Stopwatch()..start();
    try {
      booking.updatedAt = DateTime.now();
      await booking.save();
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'booking_${booking.id}_update',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'booking_${booking.id}_update',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      rethrow;
    }
  }
  
  Future<void> deleteBooking(String id) async {
    final stopwatch = Stopwatch()..start();
    try {
      await _bookingBox.delete(id);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'booking_${id}_delete',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'booking_${id}_delete',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      rethrow;
    }
  }
  
  // ============ Weather Cache ============
  
  Future<void> cacheWeather(HiveCachedWeather weather) async {
    final stopwatch = Stopwatch()..start();
    try {
      await _weatherBox.put(weather.locationKey, weather);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'weather_${weather.locationKey}',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'weather_${weather.locationKey}',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
    }
  }
  
  HiveCachedWeather? getCachedWeather(String locationKey) {
    final stopwatch = Stopwatch()..start();
    try {
      final weather = _weatherBox.get(locationKey);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'weather_$locationKey',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      // Check if cache is expired
      if (weather != null && weather.isExpired()) {
        _weatherBox.delete(locationKey);
        return null;
      }
      return weather;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'weather_$locationKey',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return null;
    }
  }
  
  // ============ Location History ============
  
  Future<void> saveLastLocation(HiveLastLocation location) async {
    final stopwatch = Stopwatch()..start();
    try {
      await _locationBox.put('last_location', location);
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'last_location',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'last_location',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
    }
  }
  
  HiveLastLocation? getLastLocation() {
    final stopwatch = Stopwatch()..start();
    try {
      final location = _locationBox.get('last_location');
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'last_location',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
      return location;
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'hive',
        dataKey: 'last_location',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return null;
    }
  }
  
  // ============ Sync Operations ============
  
  Future<void> markBookingAsSynced(String id) async {
    final booking = getBooking(id);
    if (booking != null) {
      booking.synced = true;
      await updateBooking(booking);
    }
  }
  
  int getPendingBookingsCount() => getPendingBookings().length;
  
  Future<void> clearAll() async {
    final stopwatch = Stopwatch()..start();
    try {
      await _bookingBox.clear();
      await _weatherBox.clear();
      await _locationBox.clear();
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'clear_all',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: true,
        timestamp: DateTime.now(),
      ));
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'hive',
        dataKey: 'clear_all',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
    }
  }
  
  PerformanceTracker getTracker() => _tracker;
}
