import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/hive_models.dart';
import '../models/storage_performance.dart';

/// Service untuk Supabase - cloud storage utama
class SupabaseService {
  static final SupabaseService _instance = SupabaseService._internal();
  
  factory SupabaseService() {
    return _instance;
  }
  
  SupabaseService._internal();
  
  // TODO: Ganti dengan Supabase URL dan Key Anda
  final String _supabaseUrl = 'https://your-project.supabase.co';
  final String _supabaseKey = 'your-anon-key';
  final String _apiPath = '/rest/v1';
  
  late String _authToken;
  late Map<String, dynamic> _user;
  final PerformanceTracker _tracker = PerformanceTracker();
  
  bool get isAuthenticated => _authToken.isNotEmpty;
  Map<String, dynamic> get currentUser => _user;
  
  // ============ Authentication ============
  
  Future<bool> signUp(String email, String password) async {
    final stopwatch = Stopwatch()..start();
    try {
      final response = await http.post(
        Uri.parse('$_supabaseUrl/auth/v1/signup'),
        headers: {
          'apikey': _supabaseKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      ).timeout(const Duration(seconds: 15));
      
      stopwatch.stop();
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _authToken = data['session']['access_token'];
        _user = data['user'];
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'auth_signup',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: true,
          timestamp: DateTime.now(),
        ));
        return true;
      } else {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'auth_signup',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: false,
          errorMessage: 'Status: ${response.statusCode}',
          timestamp: DateTime.now(),
        ));
        return false;
      }
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'supabase',
        dataKey: 'auth_signup',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return false;
    }
  }
  
  Future<bool> signIn(String email, String password) async {
    final stopwatch = Stopwatch()..start();
    try {
      final response = await http.post(
        Uri.parse('$_supabaseUrl/auth/v1/token?grant_type=password'),
        headers: {
          'apikey': _supabaseKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      ).timeout(const Duration(seconds: 15));
      
      stopwatch.stop();
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _authToken = data['access_token'];
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'auth_signin',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: true,
          timestamp: DateTime.now(),
        ));
        return true;
      } else {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'auth_signin',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: false,
          errorMessage: 'Status: ${response.statusCode}',
          timestamp: DateTime.now(),
        ));
        return false;
      }
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'supabase',
        dataKey: 'auth_signin',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return false;
    }
  }
  
  // ============ Booking CRUD ============
  
  Future<String?> insertBooking(HiveBooking booking) async {
    final stopwatch = Stopwatch()..start();
    try {
      final response = await http.post(
        Uri.parse('$_supabaseUrl$_apiPath/bookings'),
        headers: {
          'apikey': _supabaseKey,
          'Authorization': 'Bearer $_authToken',
          'Content-Type': 'application/json',
          'Prefer': 'return=representation',
        },
        body: jsonEncode(booking.toJson()),
      ).timeout(const Duration(seconds: 15));
      
      stopwatch.stop();
      
      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'booking_insert_${booking.id}',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: true,
          timestamp: DateTime.now(),
        ));
        return data[0]['id'];
      } else {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'booking_insert_${booking.id}',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: false,
          errorMessage: 'Status: ${response.statusCode}',
          timestamp: DateTime.now(),
        ));
        return null;
      }
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'supabase',
        dataKey: 'booking_insert_${booking.id}',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return null;
    }
  }
  
  Future<List<dynamic>> getBookings() async {
    final stopwatch = Stopwatch()..start();
    try {
      final response = await http.get(
        Uri.parse('$_supabaseUrl$_apiPath/bookings'),
        headers: {
          'apikey': _supabaseKey,
          'Authorization': 'Bearer $_authToken',
        },
      ).timeout(const Duration(seconds: 15));
      
      stopwatch.stop();
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        _tracker.addLog(StoragePerformanceLog(
          operation: 'read',
          storageType: 'supabase',
          dataKey: 'all_bookings',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: true,
          timestamp: DateTime.now(),
        ));
        return data;
      } else {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'read',
          storageType: 'supabase',
          dataKey: 'all_bookings',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: false,
          errorMessage: 'Status: ${response.statusCode}',
          timestamp: DateTime.now(),
        ));
        return [];
      }
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'read',
        storageType: 'supabase',
        dataKey: 'all_bookings',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return [];
    }
  }
  
  Future<bool> updateBooking(String id, HiveBooking booking) async {
    final stopwatch = Stopwatch()..start();
    try {
      final response = await http.patch(
        Uri.parse('$_supabaseUrl$_apiPath/bookings?id=eq.$id'),
        headers: {
          'apikey': _supabaseKey,
          'Authorization': 'Bearer $_authToken',
          'Content-Type': 'application/json',
        },
        body: jsonEncode(booking.toJson()),
      ).timeout(const Duration(seconds: 15));
      
      stopwatch.stop();
      
      if (response.statusCode == 204) {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'booking_update_$id',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: true,
          timestamp: DateTime.now(),
        ));
        return true;
      } else {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'booking_update_$id',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: false,
          errorMessage: 'Status: ${response.statusCode}',
          timestamp: DateTime.now(),
        ));
        return false;
      }
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'supabase',
        dataKey: 'booking_update_$id',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return false;
    }
  }
  
  Future<bool> deleteBooking(String id) async {
    final stopwatch = Stopwatch()..start();
    try {
      final response = await http.delete(
        Uri.parse('$_supabaseUrl$_apiPath/bookings?id=eq.$id'),
        headers: {
          'apikey': _supabaseKey,
          'Authorization': 'Bearer $_authToken',
        },
      ).timeout(const Duration(seconds: 15));
      
      stopwatch.stop();
      
      if (response.statusCode == 204) {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'booking_delete_$id',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: true,
          timestamp: DateTime.now(),
        ));
        return true;
      } else {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'booking_delete_$id',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: false,
          errorMessage: 'Status: ${response.statusCode}',
          timestamp: DateTime.now(),
        ));
        return false;
      }
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'supabase',
        dataKey: 'booking_delete_$id',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return false;
    }
  }
  
  // ============ File Upload ============
  
  Future<String?> uploadBookingPhoto(String filePath, String bookingId) async {
    final stopwatch = Stopwatch()..start();
    try {
      final file = await http.MultipartFile.fromPath('file', filePath);
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$_supabaseUrl/storage/v1/object/bookings/$bookingId'),
      );
      
      request.headers['apikey'] = _supabaseKey;
      request.headers['Authorization'] = 'Bearer $_authToken';
      request.files.add(file);
      
      final response = await request.send();
      stopwatch.stop();
      
      if (response.statusCode == 200) {
        final url = '$_supabaseUrl/storage/v1/object/public/bookings/$bookingId';
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'photo_upload_$bookingId',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: true,
          timestamp: DateTime.now(),
        ));
        return url;
      } else {
        _tracker.addLog(StoragePerformanceLog(
          operation: 'write',
          storageType: 'supabase',
          dataKey: 'photo_upload_$bookingId',
          executionTimeMs: stopwatch.elapsedMilliseconds,
          success: false,
          errorMessage: 'Status: ${response.statusCode}',
          timestamp: DateTime.now(),
        ));
        return null;
      }
    } catch (e) {
      stopwatch.stop();
      _tracker.addLog(StoragePerformanceLog(
        operation: 'write',
        storageType: 'supabase',
        dataKey: 'photo_upload_$bookingId',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        success: false,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      ));
      return null;
    }
  }
  
  // ============ Realtime Listener ============
  
  /// Subscribe untuk realtime updates pada booking
  /// Implementasi dengan WebSocket jika perlu
  Future<void> listenToBookingChanges(String bookingId, Function(Map<String, dynamic>) callback) async {
    // TODO: Implementasi WebSocket untuk realtime updates
    print('[SupabaseService] Listening to changes for booking: $bookingId');
  }
  
  PerformanceTracker getTracker() => _tracker;
}
